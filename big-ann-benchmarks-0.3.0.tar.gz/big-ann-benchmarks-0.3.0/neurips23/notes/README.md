# Additional notes NeurIPS'23 challenge

- [HNSW vs. Vamana streaming comparison](streaming/hnsw_result/hnsw_result.md) (contributed by [ekzhu](https://github.com/ekzhu))

