python install.py --neurips23track sparse --algorithm cufe
python install.py --neurips23track sparse --algorithm linscan
python install.py --neurips23track sparse --algorithm nle
python install.py --neurips23track sparse --algorithm pyanns
python install.py --neurips23track sparse --algorithm shnsw
python install.py --neurips23track sparse --algorithm spmat
python install.py --neurips23track sparse --algorithm sustech-whu
