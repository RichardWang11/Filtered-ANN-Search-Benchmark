from benchmark.algorithms.base_runner import BaseRunner

class SparseRunner(BaseRunner):
    pass