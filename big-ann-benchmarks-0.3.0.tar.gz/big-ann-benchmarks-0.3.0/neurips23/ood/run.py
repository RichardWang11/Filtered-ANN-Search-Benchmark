from benchmark.algorithms.base_runner import BaseRunner
import time

class OODRunner(BaseRunner):
    pass