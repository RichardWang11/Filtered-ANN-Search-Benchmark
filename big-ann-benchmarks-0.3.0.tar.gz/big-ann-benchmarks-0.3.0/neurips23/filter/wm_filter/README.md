
### Submission for Neurips23 Filter track of WM_filter team
This submission leverages the IVF index to run the filter in a fast way.

More info to come...


